package com.pexp7.signalseeker

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.telephony.*
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var wifiManager: WifiManager
    private var bluetoothAdapter: BluetoothAdapter? = null
    private lateinit var telephonyManager: TelephonyManager
    
    private lateinit var btnScan: Button
    private lateinit var btnAbout: Button
    private lateinit var listView: ListView
    private lateinit var tvStatus: TextView
    
    private val scanResults = mutableListOf<ScanResultItem>()
    private lateinit var adapter: ScanAdapter

    private val scanPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.READ_PHONE_STATE
        )
    } else {
        arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.READ_PHONE_STATE
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        btnScan = findViewById(R.id.btnScan)
        btnAbout = findViewById(R.id.btnAbout)
        listView = findViewById(R.id.listView)
        tvStatus = findViewById(R.id.tvStatus)

        adapter = ScanAdapter(this, scanResults)
        listView.adapter = adapter

        btnScan.setOnClickListener {
            if (checkAndRequestPermissions()) {
                startScanning()
            }
        }

        btnAbout.setOnClickListener {
            showAboutDialog()
        }
    }

    private fun showAboutDialog() {
        val message = """
            Signal Seeker v1.0
            Package: ${packageName}
            
            Developer: Pexp7
            Email: eglit.pavel@bk.ru
            GitHub: https://github.com/orbitaOS
        """.trimIndent()

        val builder = AlertDialog.Builder(this, androidx.appcompat.R.style.Theme_AppCompat_Light_Dialog_Alert)
        builder.setTitle("About")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun checkAndRequestPermissions(): Boolean {
        val missingPermissions = scanPermissions.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missingPermissions.toTypedArray(), 100)
            return false
        }

        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            tvStatus.text = "Ошибка: Включите GPS для сканирования"
            return false
        }

        return true
    }

    private fun startScanning() {
        scanResults.clear()
        adapter.notifyDataSetChanged()
        tvStatus.text = "Сканирование..."

        scanWifi()
        scanBluetoothClassic()
        scanBluetoothLE()
        scanCellular()
    }

    @SuppressLint("MissingPermission")
    private fun scanWifi() {
        val wifiReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val results = wifiManager.scanResults
                results.forEach {
                    addOrUpdateResult(ScanResultItem("Wi-Fi", it.SSID, it.BSSID, it.level, it.capabilities))
                }
                unregisterReceiver(this)
                updateStatus()
            }
        }
        registerReceiver(wifiReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
        wifiManager.startScan()
    }

    @SuppressLint("MissingPermission")
    private fun scanBluetoothClassic() {
        val btReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (BluetoothDevice.ACTION_FOUND == intent.action) {
                    val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    val rssi: Int = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    device?.let {
                        addOrUpdateResult(ScanResultItem("BT", it.name ?: "Unknown", it.address, rssi))
                    }
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED == intent.action) {
                    unregisterReceiver(this)
                    updateStatus()
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        registerReceiver(btReceiver, filter)
        bluetoothAdapter?.startDiscovery()
    }

    @SuppressLint("MissingPermission")
    private fun scanBluetoothLE() {
        val scanner = bluetoothAdapter?.bluetoothLeScanner
        val leCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                addOrUpdateResult(ScanResultItem("BLE", result.device.name ?: "Unknown", result.device.address, result.rssi))
            }
        }
        scanner?.startScan(leCallback)
        // Stop BLE scan after 10 seconds to save battery
        android.os.Handler(mainLooper).postDelayed({
            scanner?.stopScan(leCallback)
            updateStatus()
        }, 10000)
    }

    @SuppressLint("MissingPermission")
    private fun scanCellular() {
        val cellInfoList = telephonyManager.allCellInfo
        cellInfoList?.forEach { info ->
            var type = "CELL"
            var id = "Unknown"
            var rssi = -113 // Default min RSRP

            when (info) {
                is CellInfoLte -> {
                    type = "LTE"
                    id = info.cellIdentity.ci.toString()
                    rssi = info.cellSignalStrength.dbm
                }
                is CellInfoGsm -> {
                    type = "GSM"
                    id = info.cellIdentity.cid.toString()
                    rssi = info.cellSignalStrength.dbm
                }
                is CellInfoWcdma -> {
                    type = "WCDMA"
                    id = info.cellIdentity.cid.toString()
                    rssi = info.cellSignalStrength.dbm
                }
                // For Android 10+ (API 29+) we can handle NR (5G)
                is CellInfoNr -> {
                    type = "5G"
                    // Extracting NR identity and signal strength requires careful casting
                    id = "NR_Cell" 
                    rssi = info.cellSignalStrength.dbm
                }
            }
            addOrUpdateResult(ScanResultItem("CELL", type, id, rssi))
        }
        updateStatus()
    }

    private fun addOrUpdateResult(item: ScanResultItem) {
        runOnUiThread {
            val index = scanResults.indexOf(item)
            if (index != -1) {
                scanResults[index] = item
            } else {
                scanResults.add(item)
            }
            
            // Grouping: Sort by type, then by signal strength (descending)
            scanResults.sortWith(compareBy<ScanResultItem> { it.type }.thenByDescending { it.rssi })

            adapter.notifyDataSetChanged()
        }
    }

    private fun updateStatus() {
        runOnUiThread {
            tvStatus.text = "Найдено устройств: ${scanResults.size}"
        }
    }
}
