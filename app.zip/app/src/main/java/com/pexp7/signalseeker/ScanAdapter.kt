package com.pexp7.signalseeker

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class ScanAdapter(context: Context, results: List<ScanResultItem>) :
    ArrayAdapter<ScanResultItem>(context, android.R.layout.simple_list_item_1, results) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent) as TextView
        val item = getItem(position)

        item?.let {
            val prefix = when (it.type) {
                "Wi-Fi" -> "[Wi-Fi]"
                "BT" -> "[BT   ]"
                "BLE" -> "[BLE  ]"
                "CELL" -> "[CELL ]"
                else -> "[UNK  ]"
            }
            
            val displayText = String.format(
                "%-7s %-15s | %4d dBm",
                prefix,
                if (it.name.length > 15) it.name.substring(0, 12) + "..." else it.name,
                it.rssi
            )
            
            view.text = displayText
            view.typeface = Typeface.MONOSPACE
            view.textSize = 12f
            
            // Highlight headers or specific types if needed
            when (it.type) {
                "Wi-Fi" -> view.setTextColor(Color.parseColor("#000080")) // Navy Blue
                "BT" -> view.setTextColor(Color.parseColor("#800000"))    // Maroon
                "BLE" -> view.setTextColor(Color.parseColor("#008000"))   // Green
                "CELL" -> view.setTextColor(Color.parseColor("#800080"))  // Purple
                else -> view.setTextColor(Color.BLACK)
            }

            view.setPadding(8, 4, 8, 4)
        }
        
        return view
    }
}
