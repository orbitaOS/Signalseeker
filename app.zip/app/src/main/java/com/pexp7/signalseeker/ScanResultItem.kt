package com.pexp7.signalseeker

data class ScanResultItem(
    val type: String,
    val name: String,
    val address: String,
    val rssi: Int,
    val extraInfo: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ScanResultItem) return false
        return address == other.address && type == other.type
    }

    override fun hashCode(): Int {
        var result = type.hashCode()
        result = 31 * result + address.hashCode()
        return result
    }
}
